import { NextResponse } from 'next/server';
import { z } from 'zod';
import { ROOT_VERSION } from '@/lib/version';
const schema = z.object({ missionId: z.string().min(1), lesson: z.string().min(1), category: z.enum(['decision','evidence','result','failure','lesson','preference']).default('lesson') });
const memory: Array<z.infer<typeof schema> & { createdAt:string }> = [];
export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: 'INVALID_MEMORY_REQUEST' }, { status: 400 });
  const item = { ...parsed.data, createdAt: new Date().toISOString() }; memory.push(item);
  return NextResponse.json({ version: ROOT_VERSION, ok: true, memory: item, count: memory.length, persistence: 'PROCESS_MEMORY_ONLY', note: 'Connect Postgres for durable production memory.' });
}
