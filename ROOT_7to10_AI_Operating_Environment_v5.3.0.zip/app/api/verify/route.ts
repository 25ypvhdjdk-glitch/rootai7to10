import { NextResponse } from 'next/server';
import { z } from 'zod';
import { ROOT_VERSION } from '@/lib/version';
const schema = z.object({ missionId: z.string().min(1), result: z.string().min(1), criteria: z.array(z.string()).default([]) });
export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: 'INVALID_VERIFY_REQUEST' }, { status: 400 });
  return NextResponse.json({ version: ROOT_VERSION, missionId: parsed.data.missionId, status: 'NEEDS_HUMAN_VERIFICATION', criteria: parsed.data.criteria, observed: parsed.data.result.slice(0, 4000), verified: [], unknown: ['External-world truth has not been independently checked.'], next: 'HUMAN_CHECK → EVOLVE' });
}
