import { NextResponse } from 'next/server';
import { z } from 'zod';
import { ROOT_VERSION } from '@/lib/version';
import { classifyRisk } from '@/lib/root';
const schema = z.object({ missionId: z.string().min(1), mission: z.string().min(1), approved: z.boolean() });
export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: 'INVALID_EXECUTION_REQUEST' }, { status: 400 });
  const { missionId, mission, approved } = parsed.data; const risk = classifyRisk(mission);
  if (!approved) return NextResponse.json({ version: ROOT_VERSION, missionId, state: 'BLOCKED', reason: 'HUMAN_APPROVAL_REQUIRED' }, { status: 403 });
  if (risk === 'HIGH') return NextResponse.json({ version: ROOT_VERSION, missionId, state: 'BLOCKED', reason: 'HIGH_RISK_HUMAN_GATE_REQUIRED', next: 'COMPLETE_EXPLICIT_HUMAN_AUTHORIZATION' }, { status: 403 });
  return NextResponse.json({ version: ROOT_VERSION, missionId, state: 'READY_FOR_EXECUTION', risk, execution: 'NOT_PERFORMED', note: 'v5.3 plans and authorizes execution; external side effects require connected tools and explicit human authorization.' });
}
