export const ROOT_VERSION = '5.3.0';
export const ROOT_ARCHITECTURE = '7¹⁰';
export const ROOT_RELEASE = 'AI COMMAND ENGINE';
