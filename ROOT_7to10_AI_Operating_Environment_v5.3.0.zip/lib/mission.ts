import { randomUUID } from 'node:crypto';
import { classifyRisk } from './root';
import { ROOT_ARCHITECTURE, ROOT_RELEASE, ROOT_VERSION } from './version';

export type Mission = ReturnType<typeof createMission>;

export function createMission(text: string) {
  const mission = text.trim();
  const risk = classifyRisk(mission);
  const missionId = randomUUID();
  return {
    version: ROOT_VERSION,
    release: ROOT_RELEASE,
    architecture: ROOT_ARCHITECTURE,
    missionId,
    mission,
    risk,
    state: 'READY',
    planningOnly: true,
    humanApprovalRequired: true,
    gates: { intent: true, reality: false, scale: false },
    evidence: { observed: [mission], verified: [], estimated: [], assumed: [], unknown: ['External-world facts have not been independently verified.'] },
    tasks: [
      { id: `${missionId}:1`, command: 'DEFINE', owner: 'Coordinator', status: 'READY', purpose: 'Clarify objective, desired outcome, success criteria and constraints.' },
      { id: `${missionId}:2`, command: 'DISCOVER', owner: 'Researcher', status: 'QUEUED', purpose: 'Identify information needs, gather evidence and surface unknowns.' },
      { id: `${missionId}:3`, command: 'ARCHITECT', owner: 'Architect', status: 'QUEUED', purpose: 'Design workflow, dependencies, resources, checkpoints and controls.' },
      { id: `${missionId}:4`, command: 'CREATE_BUILD', owner: 'Builder', status: 'QUEUED', purpose: 'Create the smallest useful result after required approval.' },
      { id: `${missionId}:5`, command: 'VERIFY', owner: 'Auditor', status: 'QUEUED', purpose: 'Test the result against explicit success and failure criteria.' },
      { id: `${missionId}:6`, command: 'EVOLVE', owner: 'Optimizer', status: 'QUEUED', purpose: 'Capture feedback, improve the system and define the next action.' }
    ],
    next: risk === 'HIGH' ? 'APPROVE PLAN → EXECUTE WITH HUMAN GATE → VERIFY' : 'APPROVE PLAN → EXECUTE → VERIFY → EVOLVE'
  };
}
