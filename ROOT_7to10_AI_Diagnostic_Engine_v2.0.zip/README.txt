ROOT 7¹⁰ AI Diagnostic Engine v2.0
Open index.html to run the interview prototype.
The API route is a reference contract for connecting a real AI model.
v2.0 keeps human review and evidence verification as explicit gates.
