# ROOT 7¹⁰ AI DIAGNOSTIC ENGINE v2.0

## What changed
v1.1 calculated scores from a 70-cell matrix.
v2.0 adds an AI diagnostic interview layer.

## Operating loop
INTERVIEW → CLASSIFY EVIDENCE → PROPOSE SCORES → IDENTIFY BOTTLENECK → APPLY GATES → BUILD PLAN → HUMAN REVIEW → INTERVENE → VERIFY → REASSESS

## AI scoring policy
The model may propose:
- capability score
- confidence
- evidence classification
- rationale
- missing evidence
- recommended verification test

The model must not silently convert an assertion into a verified score.

## Evidence classes
OBSERVED
VERIFIED
ESTIMATED
ASSUMED
INFERRED
UNKNOWN
CONFLICTING
OBSOLETE

## Bottleneck logic
Prefer the weakness that:
1. has high downstream dependency,
2. materially affects the target outcome,
3. has a meaningful capability gap,
4. can be improved with a bounded intervention.

Do not simply select the lowest number.

## Three gates
INTENT — /MISSION
REALITY — /VERIFY + /SIMULATE
SCALE — /OPTIMIZE + /AUTOMATE

A failed gate changes the recommended action:
- failed INTENT: clarify before building
- failed REALITY: verify before trusting
- failed SCALE: optimize before automating

## Human authority
AI can diagnose and recommend. The human retains authority over consequential decisions, including money, legal, employment, sensitive data, security permissions, destructive actions, and irreversible changes.

## Production roadmap
v2.1 — connect real model provider and structured output.
v2.2 — evidence upload + citations/traceability.
v2.3 — persistent assessments and history.
v2.4 — comparative before/after diagnostics.
v3.0 — multi-agent diagnostic orchestration.

## Important
The included interface is a functional front-end prototype and reference API contract. A production deployment still requires model credentials, persistence, authentication, rate limits, privacy controls, and testing.
