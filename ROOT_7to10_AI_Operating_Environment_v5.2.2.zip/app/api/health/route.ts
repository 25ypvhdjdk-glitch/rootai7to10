import {hasAuth,hasDatabase,hasGateway} from '@/lib/config'; import {storageStatus} from '@/lib/storage';
export async function GET(){return Response.json({ok:true,version:'5.2.1',runtime:'nextjs',aiGateway:hasGateway,auth:hasAuth,database:hasDatabase,storage:storageStatus(),humanAuthority:true,timestamp:new Date().toISOString()});}
